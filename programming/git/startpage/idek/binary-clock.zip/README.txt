A Pen created at CodePen.io. You can find this one at http://codepen.io/Hammertime38/pen/crtEg.

 Inspired by Fabrice Weinberg's "CSS Digital Clock", completely reconfigured and converted to binary.

More dependent JS and simplistic CSS.

*Edited to run as an object, much more to customize in the JS